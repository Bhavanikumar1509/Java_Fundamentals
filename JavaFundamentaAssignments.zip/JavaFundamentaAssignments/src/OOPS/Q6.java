package OOPS;

public class Q6 {

}
