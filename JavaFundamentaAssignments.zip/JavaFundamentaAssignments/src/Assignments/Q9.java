package Assignments;

public class Q9 {
	public static void main(String[] args) {
		System.out.println("N\tN*10\tN*100\tN*1000");
		for(int i=1;i<=5;i++) {
			System.out.println(i+"\t"+i*10+"\t"+i*100+"\t"+i*1000);
		}
	}

}
