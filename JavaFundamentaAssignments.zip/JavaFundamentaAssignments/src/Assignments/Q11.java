package Assignments;

public class Q11 {
	public static void main(String[] args) {
		int array[]={0,0,0,0,0,0,0,0,0,0}; 
	 	int bonus[];
	 	bonus=new int[15];  
	 	for(int i=0;i<15;i++){ 
	 		bonus[i]+=1;
	 	}

	 	int bestScores[]={69,53,60,78,79};
	 	for (int j=0;j<5;j++){
	 		System.out.printf("%d\t", bestScores[j]); 

	 	}
	}

}
