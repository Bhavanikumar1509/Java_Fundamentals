package Assignments;

public class Q3 {
	public static void main(String[] args) {
		System.out.println("1 2 3 4");
		System.out.print("1 ");
		System.out.print("2 ");
		System.out.print("3 ");
		System.out.print("4 ");
		System.out.printf("\n1 2 3 4");
		
	}

}
